</div>
<footer class="site">© 2025 Smart Campus · PNU</footer>
</body></html>
