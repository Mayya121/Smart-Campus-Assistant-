<?php
require_once "auth.php"; require_perm('reserve'); require_once "db_connect.php";
$room=trim($_POST['room_id']??''); $date=trim($_POST['date']??''); $time=trim($_POST['time']??'');
if(!$room||!$date||!$time){ exit("Missing fields."); }
$uid=user()['id'];
$stmt=$mysqli->prepare("INSERT INTO reservations (user_id,room_id,date,time,status) VALUES (?,?,?,?, 'pending')");
$stmt->bind_param('isss',$uid,$room,$date,$time);
$ok=$stmt->execute(); $stmt->close();
$title="Reserve"; include "header.php";
echo '<div class="card w-420">'.($ok?'<h3>Reservation submitted ✅</h3>':'<h3>Failed to reserve ❌</h3>').'<p><a class="btn" href="student_dashboard.php">Back</a></p></div>';
include "footer.php";
