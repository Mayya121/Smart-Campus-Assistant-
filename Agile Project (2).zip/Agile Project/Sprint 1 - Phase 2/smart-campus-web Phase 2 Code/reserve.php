<?php require_once "auth.php"; require_perm('reserve'); $title="Reserve a classroom"; include "header.php"; ?>
<div class="card w-420">
  <h2>Reserve a classroom</h2>
  <form method="post" action="reserve_action.php">
    <label>Classroom</label>
    <select class="input" name="room_id"><option>A101</option><option>B202</option><option>C303</option></select>
    <div class="form-row">
      <div><label>Date</label><input class="input" type="date" name="date" required></div>
      <div><label>Time</label><input class="input" type="time" name="time" required></div>
    </div>
    <div style="margin-top:12px"><button class="btn" type="submit">Reserve</button></div>
  </form>
</div>
<?php include "footer.php"; ?>
