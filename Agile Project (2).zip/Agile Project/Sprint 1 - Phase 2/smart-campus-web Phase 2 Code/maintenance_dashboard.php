<?php require_once "auth.php"; require_perm('maint'); require_once "db_connect.php"; $title="Maintenance"; include "header.php"; ?>
<div class="card">
  <h2>Maintenance requests</h2>
  <form class="form-row" method="get" action="search_maintenance.php">
    <div><label>Room contains</label><input class="input" name="room"></div>
    <div style="align-self:end"><button class="btn secondary" type="submit">Search</button></div>
  </form>
  <table class="table" style="margin-top:10px">
    <tr><th>ID</th><th>Room</th><th>Status</th><th>Created</th></tr>
    <?php $q=$mysqli->query("SELECT id,room_id,status,created_at FROM maintenance_requests ORDER BY created_at DESC LIMIT 20");
      while($r=$q->fetch_assoc()){ echo "<tr><td>{$r['id']}</td><td>".htmlspecialchars($r['room_id'])."</td><td>{$r['status']}</td><td>{$r['created_at']}</td></tr>"; } ?>
  </table>
</div>
<?php include "footer.php"; ?>
