<?php
if (session_status() === PHP_SESSION_NONE) session_start();

function logged_in(){ return !empty($_SESSION['user']); }
function user(){ return $_SESSION['user'] ?? null; }
function role(){ return $_SESSION['user']['role'] ?? 'guest'; }

function can($perm){
  $r = role();
  $map = [
    'student' => ['schedule'],
    'faculty' => ['schedule','reserve','modify'],
    'admin'   => ['schedule','reserve','modify','maint','admin']
  ];
  return in_array($perm, $map[$r] ?? []);
}
function require_login(){ if(!logged_in()){ header("Location: login.php"); exit; } }
function require_perm($perm){ require_login(); if(!can($perm)){ http_response_code(403); exit("403 • Forbidden"); } }
