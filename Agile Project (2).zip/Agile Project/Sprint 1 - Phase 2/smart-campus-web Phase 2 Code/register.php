<?php
require_once "auth.php"; require_once "db_connect.php";
$msg=""; $err="";
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name=trim($_POST['name']??''); $email=trim($_POST['email']??''); $pass=$_POST['password']??'';
  if($name===''||$email===''||$pass===''){ $err="All fields are required"; }
  elseif(!preg_match('/@pnu\.edu\.sa$/i',$email)){ $err="Only @pnu.edu.sa emails allowed"; }
  else{
    $role = preg_match('/^\d+@pnu\.edu\.sa$/',$email) ? 'student' : 'faculty';
    $hash=password_hash($pass,PASSWORD_BCRYPT);
    $stmt=$mysqli->prepare("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)");
    $stmt->bind_param('ssss',$name,$email,$hash,$role);
    if($stmt->execute()){ $msg="Account created. You can sign in."; } else { $err="Email already exists."; }
    $stmt->close();
  }
}
$title="Register"; include "header.php";
?>
<div class="center"><div class="card w-420">
<h2>Create account</h2>
<?php if($msg): ?><p class="notice" style="background:#dcfce7;color:#065f46"><?= htmlspecialchars($msg) ?></p><?php endif; ?>
<?php if($err): ?><p class="notice"><?= htmlspecialchars($err) ?></p><?php endif; ?>
<form method="post">
  <label>Name</label><input class="input" name="name" required>
  <label>Email</label><input class="input" type="email" name="email" placeholder="123456789@pnu.edu.sa" required>
  <label>Password</label><input class="input" type="password" name="password" required>
  <div style="margin-top:12px"><button class="btn" type="submit">Create</button></div>
</form>
</div></div>
<?php include "footer.php"; ?>
