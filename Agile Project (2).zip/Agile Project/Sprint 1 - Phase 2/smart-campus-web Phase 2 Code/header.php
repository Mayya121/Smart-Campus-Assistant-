<?php require_once __DIR__."/auth.php"; ?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= isset($title)? htmlspecialchars($title) : 'Smart Campus' ?></title>
<link rel="stylesheet" href="assets/style.css">
</head><body>
<nav class="topbar"><div class="inner">
  <div class="brand">Smart Campus</div>
  <div class="nav">
    <a href="student_dashboard.php">Home</a>
    <?php if (can('reserve')): ?><a href="reserve.php">Reserve</a><a href="modify_booking.php">Modify / Cancel</a><?php endif; ?>
    <?php if (can('schedule')): ?><a href="get_schedule.php">Schedule</a><?php endif; ?>
    <?php if (can('maint')): ?><a href="maintenance_dashboard.php">Maintenance</a><?php endif; ?>
    <?php if (can('admin')): ?><a href="admin.php">Admin</a><?php endif; ?>
  </div>
  <div>
    <?php if (logged_in()): ?>
      <span class="badge">Hi, <?= htmlspecialchars(user()['name']??'') ?></span>
      <a class="btn secondary" href="logout.php">Logout</a>
    <?php else: ?>
      <a class="btn" href="login.php">Login</a>
    <?php endif; ?>
  </div>
</div></nav>
<div class="container">

