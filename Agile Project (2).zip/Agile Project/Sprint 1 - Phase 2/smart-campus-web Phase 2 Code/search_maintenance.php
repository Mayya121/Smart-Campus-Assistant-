<?php require_once "auth.php"; require_perm('maint'); require_once "db_connect.php"; $title="Search maintenance"; include "header.php";
$room=trim($_GET['room']??'');
?>
<div class="card"><h2>Search results</h2>
<table class="table"><tr><th>ID</th><th>Room</th><th>Status</th></tr>
<?php $stmt=$mysqli->prepare("SELECT id,room_id,status FROM maintenance_requests WHERE room_id LIKE CONCAT('%',?,'%') ORDER BY id DESC");
$stmt->bind_param('s',$room); $stmt->execute(); $res=$stmt->get_result();
while($r=$res->fetch_assoc()){ echo "<tr><td>{$r['id']}</td><td>".htmlspecialchars($r['room_id'])."</td><td>{$r['status']}</td></tr>"; } $stmt->close(); ?>
</table><p><a class="btn secondary" href="maintenance_dashboard.php">Back</a></p></div>
<?php include "footer.php"; ?>

