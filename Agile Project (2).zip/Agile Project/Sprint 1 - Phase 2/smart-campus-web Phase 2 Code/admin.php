<?php require_once "auth.php"; require_perm('admin'); $title="Admin"; include "header.php"; ?>
<h2>Admin panel</h2>
<p>Manage users, schedule and reservations via DB. This simple panel validates role-based access.</p>
<?php include "footer.php"; ?>
