<?php
include '../db_connect.php';
function notify_user($email,$subject,$body){
  global $mysqli;
  $s=$mysqli->prepare("INSERT INTO notifications_log (user_email,subject,body) VALUES (?,?,?)");
  $s->bind_param('sss',$email,$subject,$body); $s->execute(); $s->close();
  return true; // فيما بعد نضيف PHPMailer هنا
}
