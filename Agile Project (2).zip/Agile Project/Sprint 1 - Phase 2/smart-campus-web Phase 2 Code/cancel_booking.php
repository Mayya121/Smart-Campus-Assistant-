<?php require_once "auth.php"; require_perm('modify'); require_once "db_connect.php";
$id=(int)($_GET['id']??0); $uid=user()['id'];
if($id>0){ $stmt=$mysqli->prepare("UPDATE reservations SET status='cancelled' WHERE id=? AND user_id=?"); $stmt->bind_param('ii',$id,$uid); $stmt->execute(); }
header("Location: modify_booking.php");
