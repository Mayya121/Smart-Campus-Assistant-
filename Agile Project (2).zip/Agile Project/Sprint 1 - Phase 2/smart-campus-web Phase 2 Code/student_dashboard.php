<?php require_once "auth.php"; require_login(); $title="Dashboard"; include "header.php"; ?>
<h2>Welcome back 👋</h2>
<div class="grid3">
  <div class="card">
    <div class="title">Quick actions</div>
    <p>Role: <strong><?= htmlspecialchars(role()) ?></strong></p>
    <ul class="inline">
      <?php if (can('reserve')): ?>
        <li><a class="btn" href="reserve.php">Reserve a room</a></li>
        <li><a class="btn secondary" href="modify_booking.php">Modify / Cancel</a></li>
      <?php endif; ?>
      <li><a class="btn secondary" href="get_schedule.php">View schedule</a></li>
    </ul>
  </div>
  <div class="card"><div class="title">Today</div><p>Check your daily schedule.</p><a class="btn" href="get_schedule.php">Open schedule</a></div>
  <div class="card"><div class="title">Status</div><p><span class="badge">Pending reservations</span></p></div>
</div>
<?php include "footer.php"; ?>
