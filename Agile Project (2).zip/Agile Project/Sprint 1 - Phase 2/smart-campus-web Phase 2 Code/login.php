<?php
require_once "auth.php";
require_once "db_connect.php";
$err="";
if($_SERVER['REQUEST_METHOD']==='POST'){
  $email=trim($_POST['email']??''); $pass=$_POST['password']??'';
  $stmt=$mysqli->prepare("SELECT id,name,email,password_hash,role,is_active FROM users WHERE email=? LIMIT 1");
  $stmt->bind_param('s',$email); $stmt->execute();
  $u=$stmt->get_result()->fetch_assoc(); $stmt->close();
  if(!$u || !password_verify($pass,$u['password_hash'])){ $err="Invalid credentials"; }
  elseif ((int)$u['is_active']!==1){ $err="Account is disabled"; }
  else { $_SESSION['user']=['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']]; header("Location: student_dashboard.php"); exit; }
}
$title="Login"; include "header.php";
?>
<div class="center"><div class="card w-420">
<h2>Login</h2>
<?php if($err): ?><p class="notice"><?= htmlspecialchars($err) ?></p><?php endif; ?>
<form method="post">
  <label>Email</label><input class="input" type="email" name="email" required placeholder="you@pnu.edu.sa">
  <label>Password</label><input class="input" type="password" name="password" required>
  <div style="margin-top:12px"><button class="btn" type="submit">Sign in</button></div>
</form>
<p><small class="help">No account? <a href="register.php">Create one</a></small></p>
</div></div>
<?php include "footer.php"; ?>
