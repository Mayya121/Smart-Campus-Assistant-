<?php require_once "auth.php"; require_perm('schedule'); require_once "db_connect.php"; $title="Schedule"; include "header.php"; ?>
<div class="card">
<h2>Today's schedule</h2>
<table class="table"><tr><th>Time</th><th>Classroom</th><th>Course</th></tr>
<?php $q=$mysqli->query("SELECT time,classroom,course_name FROM schedule ORDER BY time");
while($r=$q->fetch_assoc()){ echo "<tr><td>{$r['time']}</td><td>".htmlspecialchars($r['classroom'])."</td><td>".htmlspecialchars($r['course_name'])."</td></tr>"; } ?>
</table></div>
<?php include "footer.php"; ?>
