<?php require_once "auth.php"; require_perm('modify'); require_once "db_connect.php"; $title="Modify / Cancel"; include "header.php";
$uid=user()['id']; $res=$mysqli->prepare("SELECT id,room_id,date,time,status FROM reservations WHERE user_id=? ORDER BY date DESC,time DESC");
$res->bind_param('i',$uid); $res->execute(); $rows=$res->get_result();
?>
<div class="card">
  <h2>My reservations</h2>
  <table class="table">
    <tr><th>#</th><th>Room</th><th>Date</th><th>Time</th><th>Status</th><th></th></tr>
    <?php while($r=$rows->fetch_assoc()): ?>
      <tr>
        <td><?= $r['id'] ?></td><td><?= htmlspecialchars($r['room_id']) ?></td><td><?= $r['date'] ?></td><td><?= $r['time'] ?></td><td><?= $r['status'] ?></td>
        <td><?php if($r['status']!=='cancelled'): ?><a class="btn danger" href="cancel_booking.php?id=<?= $r['id'] ?>" onclick="return confirm('Cancel this reservation?')">Cancel</a><?php endif; ?></td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>
<?php include "footer.php"; ?>
