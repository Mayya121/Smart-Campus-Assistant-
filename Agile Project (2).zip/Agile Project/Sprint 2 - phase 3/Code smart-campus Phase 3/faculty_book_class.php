<?php
require_once 'config.php';
require_role(['faculty']);

$info = '';

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['create_booking'])){
    $room_id = (int)($_POST['room_id'] ?? 0);
    $date = $_POST['date'] ?? '';
    $start = $_POST['start_time'] ?? '';
    $end = $_POST['end_time'] ?? '';

    if($room_id && $date && $start && $end){
        $stmt = $conn->prepare("
            SELECT id FROM bookings
            WHERE room_id=? AND date=? AND status='active'
              AND NOT (end_time <= ? OR start_time >= ?)
        ");
        $stmt->bind_param("isss",$room_id,$date,$start,$end);
        $stmt->execute(); $stmt->store_result();
        if($stmt->num_rows>0){
            $info = "This time slot is already booked.";
        } else {
            $stmt->close();
            $type = 'class';
            $uid = $_SESSION['user_id'];
            $stmt = $conn->prepare("
                INSERT INTO bookings (room_id,created_by,type,date,start_time,end_time)
                VALUES (?,?,?,?,?,?)
            ");
            $stmt->bind_param("iissss",$room_id,$uid,$type,$date,$start,$end);
            if($stmt->execute()){
                $info = "Booking created.";
                notify_role('student','schedule',"Classroom schedule updated on {$date}.");
            } else {
                $info = "Error creating booking.";
            }
        }
        $stmt->close();
    } else {
        $info="Please fill all fields.";
    }
}

$rooms = $conn->query("SELECT id,name FROM classrooms ORDER BY name");

$uid = $_SESSION['user_id'];
$stmt = $conn->prepare("
    SELECT b.id, c.name AS room_name, b.date, b.start_time, b.end_time, b.status
    FROM bookings b
    JOIN classrooms c ON c.id = b.room_id
    WHERE b.created_by=? AND b.type='class'
    ORDER BY b.date DESC, b.start_time
");
$stmt->bind_param("i",$uid);
$stmt->execute();
$myBookings = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Classroom Booking – Faculty</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Faculty</div>
            <div class="sidebar-role">Faculty Member</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="faculty_dashboard.php">Dashboard</a></li>
            <li><a href="faculty_book_class.php" class="active">Classroom Booking</a></li>
            <li><a href="faculty_create_maintenance.php">Maintenance Request</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-left">Faculty – Classroom Booking</div>
            <div class="topbar-right"><a href="logout.php">Logout</a></div>
        </div>

        <div class="content">
            <h1 class="page-title">Classroom booking</h1>
            <p class="page-subtitle">Reserve, view, and manage your classroom reservations.</p>

            <div class="form-card">
                <h3 style="margin-bottom:8px;">Create a new booking</h3>
                <?php if($info): ?>
                    <p class="<?= strpos($info,'created')!==false?'success':'error' ?>"><?= htmlspecialchars($info) ?></p>
                <?php endif; ?>

                <form method="post">
                    <div class="form-group">
                        <label>Room</label>
                        <select name="room_id" required>
                            <option value="">Select room</option>
                            <?php while($r=$rooms->fetch_assoc()): ?>
                                <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['name']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Date</label>
                        <input type="date" name="date" required>
                    </div>
                    <div class="form-group">
                        <label>Start time</label>
                        <input type="time" name="start_time" required>
                    </div>
                    <div class="form-group">
                        <label>End time</label>
                        <input type="time" name="end_time" required>
                    </div>
                    <button class="btn-primary" type="submit" name="create_booking">Reserve classroom</button>
                </form>
            </div>

            <div class="table-wrapper">
                <h3 style="margin-bottom:10px;">Your bookings</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Room</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while($b=$myBookings->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($b['room_name']) ?></td>
                            <td><?= htmlspecialchars($b['date']) ?></td>
                            <td><?= substr($b['start_time'],0,5) . "–" . substr($b['end_time'],0,5) ?></td>
                            <td><?= htmlspecialchars($b['status']) ?></td>
                            <td>
                                <?php if($b['status']==='active'): ?>
                                    <a href="faculty_edit_booking.php?id=<?= $b['id'] ?>">Edit</a> |
                                    <a href="faculty_cancel_booking.php?id=<?= $b['id'] ?>">Cancel</a>
                                <?php else: ?>
                                    –
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </main>

</div>
</body>
</html>
