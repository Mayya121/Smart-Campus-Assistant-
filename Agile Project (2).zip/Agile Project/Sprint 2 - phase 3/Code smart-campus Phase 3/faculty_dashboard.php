<?php
require_once 'config.php';
require_role(['faculty']);

$uid = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT COUNT(*) c FROM bookings WHERE created_by=? AND type='class'");
$stmt->bind_param("i",$uid);
$stmt->execute();
$bookingsCount = $stmt->get_result()->fetch_assoc()['c'] ?? 0;
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Faculty Dashboard – Smart Campus Assistant</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Faculty</div>
            <div class="sidebar-role">Faculty Member</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="faculty_dashboard.php" class="active">Dashboard</a></li>
            <li><a href="faculty_book_class.php">Classroom Booking</a></li>
            <li><a href="faculty_create_maintenance.php">Maintenance Request</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-left">Smart Campus Assistant – Faculty Panel</div>
            <div class="topbar-right">
                <a href="logout.php">Logout</a>
            </div>
        </div>

        <div class="content">
            <h1 class="page-title">Dashboard</h1>
            <p class="page-subtitle">Manage your classroom bookings and maintenance requests.</p>

            <div class="cards-grid">
                <div class="card-panel">
                    <h3>Your bookings</h3>
                    <p>Number of classroom bookings you created.</p>
                    <div class="big-number"><?= $bookingsCount ?></div>
                </div>
                <div class="card-panel">
                    <h3>Quick booking</h3>
                    <p>Create a new classroom reservation.</p>
                    <a class="btn-primary" href="faculty_book_class.php" style="margin-top:6px;">Go to booking</a>
                </div>
                <div class="card-panel">
                    <h3>Maintenance</h3>
                    <p>Report an issue in your classroom or lab.</p>
                    <a class="btn-primary" href="faculty_create_maintenance.php" style="margin-top:6px;background:#3AAFA9;">Create request</a>
                </div>
            </div>

        </div>
    </main>

</div>
</body>
</html>
