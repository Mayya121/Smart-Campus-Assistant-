<?php
require_once 'config.php';
require_role(['admin']);

$msg = '';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $id = (int)($_POST['user_id'] ?? 0);
    $role = $_POST['role'] ?? '';
    if($id && in_array($role,['admin','faculty','student','maintenance'])){
        $stmt = $conn->prepare("UPDATE users SET role=? WHERE id=?");
        $stmt->bind_param("si",$role,$id);
        if($stmt->execute()) $msg="Role updated.";
        else $msg="Error updating role.";
        $stmt->close();
    }
}
$users = $conn->query("SELECT id,full_name,email,role,created_at FROM users ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users – Admin</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Admin</div>
            <div class="sidebar-role">System Administrator</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li><a class="active" href="admin_manage_users.php">Manage Users</a></li>
            <li><a href="admin_reports.php">Reports</a></li>
            <li><a href="admin_notifications.php">Notification Settings</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-left">Admin – Manage Users</div>
            <div class="topbar-right"><a href="logout.php">Logout</a></div>
        </div>

        <div class="content">
            <h1 class="page-title">Manage users</h1>
            <p class="page-subtitle">Update user roles and permissions.</p>

            <?php if($msg): ?>
                <p class="<?= strpos($msg,'updated')!==false?'success':'error' ?>"><?= $msg ?></p>
            <?php endif; ?>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Created</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while($u=$users->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($u['full_name']) ?></td>
                            <td><?= htmlspecialchars($u['email']) ?></td>
                            <td><?= htmlspecialchars($u['role']) ?></td>
                            <td><?= htmlspecialchars($u['created_at']) ?></td>
                            <td>
                                <form method="post" style="display:flex;gap:6px;">
                                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                    <select name="role" style="padding:6px;">
                                        <option value="student" <?= $u['role']==='student'?'selected':'' ?>>student</option>
                                        <option value="faculty" <?= $u['role']==='faculty'?'selected':'' ?>>faculty</option>
                                        <option value="maintenance" <?= $u['role']==='maintenance'?'selected':'' ?>>maintenance</option>
                                        <option value="admin" <?= $u['role']==='admin'?'selected':'' ?>>admin</option>
                                    </select>
                                    <button class="table-action-btn" type="submit">Save</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </main>

</div>
</body>
</html>
