<?php
require_once 'config.php';
require_role(['faculty']);

$id = (int)($_GET['id'] ?? 0);
$uid = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT date FROM bookings WHERE id=? AND created_by=? AND type='class'");
$stmt->bind_param("ii",$id,$uid);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$stmt->close();

if($row){
    $date = $row['date'];
    $stmt = $conn->prepare("UPDATE bookings SET status='cancelled', updated_at=NOW() WHERE id=? AND created_by=?");
    $stmt->bind_param("ii",$id,$uid);
    $stmt->execute();
    $stmt->close();
    notify_role('student','schedule',"A classroom booking on {$date} has been cancelled.");
}

header("Location: faculty_book_class.php");
exit;
