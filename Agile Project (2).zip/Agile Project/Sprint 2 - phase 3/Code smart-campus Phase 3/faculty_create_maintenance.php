<?php
require_once 'config.php';
require_role(['faculty']);

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    if ($title !== '' && $description !== '') {
        $uid = $_SESSION['user_id'];
        $stmt = $conn->prepare("
            INSERT INTO maintenance_requests (created_by, title, description)
            VALUES (?,?,?)
        ");
        $stmt->bind_param("iss", $uid, $title, $description);
        if ($stmt->execute()) {
            $msg = "Maintenance request submitted.";
            notify_role('maintenance', 'maintenance', "New maintenance request: {$title}");
        } else {
            $msg = "Error submitting request.";
        }
        $stmt->close();
    } else {
        $msg = "Please fill all fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Maintenance Request – Faculty</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Faculty</div>
            <div class="sidebar-role">Faculty Member</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="faculty_dashboard.php">Dashboard</a></li>
            <li><a href="faculty_book_class.php">Classroom Booking</a></li>
            <li><a class="active" href="faculty_create_maintenance.php">Maintenance Request</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-left">Faculty – Maintenance Request</div>
            <div class="topbar-right"><a href="logout.php">Logout</a></div>
        </div>

        <div class="content">
            <h1 class="page-title">Create maintenance request</h1>
            <p class="page-subtitle">Report an issue in your classroom or faculty area.</p>

            <div class="form-card">
                <?php if($msg): ?>
                    <p class="<?= strpos($msg,'submitted')!==false?'success':'error' ?>"><?= $msg ?></p>
                <?php endif; ?>

                <form method="post">
                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" name="title" required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" rows="5" required></textarea>
                    </div>
                    <button class="btn-primary" type="submit">Submit request</button>
                </form>
            </div>

        </div>
    </main>

</div>
</body>
</html>
