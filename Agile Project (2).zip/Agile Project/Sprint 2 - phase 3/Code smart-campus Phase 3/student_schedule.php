<?php
require_once 'config.php';
require_role(['student']);

$date = $_GET['date'] ?? date('Y-m-d');

$stmt = $conn->prepare("
    SELECT c.name AS room_name, b.date, b.start_time, b.end_time
    FROM bookings b
    JOIN classrooms c ON c.id=b.room_id
    WHERE b.type='class' AND b.status='active' AND b.date=?
    ORDER BY b.start_time
");
$stmt->bind_param("s",$date);
$stmt->execute();
$res = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daily Schedule – Student</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Student</div>
            <div class="sidebar-role">Student Portal</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="student_dashboard.php">Dashboard</a></li>
            <li><a href="student_schedule.php" class="active">Daily Schedule</a></li>
            <li><a href="student_study_room.php">Study Room Booking</a></li>
            <li><a href="student_feedback.php">Send Feedback</a></li>
            <li><a href="student_notifications.php">Notifications</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-left">Student – Daily Schedule</div>
            <div class="topbar-right"><a href="logout.php">Logout</a></div>
        </div>

        <div class="content">
            <h1 class="page-title">My daily schedule</h1>
            <p class="page-subtitle">View your classes for a selected day.</p>

            <div class="form-card">
                <form method="get" class="filter-row">
                    <div style="flex:0 0 200px;">
                        <label>Date</label>
                        <input type="date" name="date" value="<?= htmlspecialchars($date) ?>">
                    </div>
                    <div style="align-self:flex-end;">
                        <button class="btn-primary" type="submit">View schedule</button>
                    </div>
                </form>
            </div>

            <div class="table-wrapper">
                <h3 style="margin-bottom:8px;">Schedule for <?= htmlspecialchars($date) ?></h3>
                <table>
                    <thead>
                        <tr>
                            <th>Room</th>
                            <th>Date</th>
                            <th>Start</th>
                            <th>End</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while($row=$res->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['room_name']) ?></td>
                            <td><?= htmlspecialchars($row['date']) ?></td>
                            <td><?= substr($row['start_time'],0,5) ?></td>
                            <td><?= substr($row['end_time'],0,5) ?></td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </main>

</div>
</body>
</html>
