<?php
require_once 'config.php';
require_role(['maintenance']);

$open = $conn->query("SELECT COUNT(*) c FROM maintenance_requests WHERE status='open'")->fetch_assoc()['c'] ?? 0;
$inProgress = $conn->query("SELECT COUNT(*) c FROM maintenance_requests WHERE status='in_progress'")->fetch_assoc()['c'] ?? 0;
$done = $conn->query("SELECT COUNT(*) c FROM maintenance_requests WHERE status='done'")->fetch_assoc()['c'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Maintenance Dashboard – Smart Campus Assistant</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Maintenance</div>
            <div class="sidebar-role">Maintenance Staff</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="maintenance_dashboard.php" class="active">Dashboard</a></li>
            <li><a href="maintenance_requests.php">Maintenance Requests</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-left">Smart Campus Assistant – Maintenance Panel</div>
            <div class="topbar-right">
                <a href="logout.php">Logout</a>
            </div>
        </div>

        <div class="content">
            <h1 class="page-title">Dashboard</h1>
            <p class="page-subtitle">View and update campus maintenance requests.</p>

            <div class="cards-grid">
                <div class="card-panel">
                    <h3>Open requests</h3>
                    <p>New issues waiting to be handled.</p>
                    <div class="big-number"><?= $open ?></div>
                </div>
                <div class="card-panel">
                    <h3>In progress</h3>
                    <p>Requests currently being handled.</p>
                    <div class="big-number"><?= $inProgress ?></div>
                </div>
                <div class="card-panel">
                    <h3>Completed</h3>
                    <p>Resolved requests.</p>
                    <div class="big-number"><?= $done ?></div>
                </div>
                <div class="card-panel">
                    <h3>Go to requests</h3>
                    <p>Open the full maintenance requests list.</p>
                    <a href="maintenance_requests.php" class="btn-primary" style="margin-top:8px;">View all requests</a>
                </div>
            </div>

        </div>
    </main>

</div>
</body>
</html>
