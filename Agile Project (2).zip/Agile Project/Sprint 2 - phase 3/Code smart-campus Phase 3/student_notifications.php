<?php
require_once 'config.php';
require_role(['student']);

$uid = $_SESSION['user_id'];

$stmt = $conn->prepare("UPDATE notifications SET is_read=1 WHERE user_id=?");
$stmt->bind_param("i",$uid);
$stmt->execute();
$stmt->close();

$stmt = $conn->prepare("
    SELECT message, created_at, is_read 
    FROM notifications
    WHERE user_id=?
    ORDER BY created_at DESC
");
$stmt->bind_param("i",$uid);
$stmt->execute();
$rows = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Notifications – Student</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Student</div>
            <div class="sidebar-role">Student Portal</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="student_dashboard.php">Dashboard</a></li>
            <li><a href="student_schedule.php">Daily Schedule</a></li>
            <li><a href="student_study_room.php">Study Room Booking</a></li>
            <li><a href="student_feedback.php">Send Feedback</a></li>
            <li><a class="active" href="student_notifications.php">Notifications</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-left">Student – Notifications</div>
            <div class="topbar-right"><a href="logout.php">Logout</a></div>
        </div>

        <div class="content">
            <h1 class="page-title">My notifications</h1>
            <p class="page-subtitle">All updates related to your bookings and system events.</p>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Message</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while($n=$rows->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($n['message']) ?></td>
                            <td><?= htmlspecialchars($n['created_at']) ?></td>
                            <td><?= $n['is_read'] ? 'read' : 'new' ?></td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </main>

</div>
</body>
</html>
