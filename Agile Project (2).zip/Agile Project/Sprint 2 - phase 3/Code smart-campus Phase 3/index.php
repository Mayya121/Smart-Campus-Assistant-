<?php
require_once 'config.php';
$mode = $_GET['mode'] ?? 'login';
$register_message = $_SESSION['register_message'] ?? '';
$login_error = $_SESSION['login_error'] ?? '';
unset($_SESSION['register_message'], $_SESSION['login_error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Campus Assistant</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="page-wrapper">


    <div class="card">
<div class="card-left">
    
<img src="logo-small.png" 
     alt="Smart Campus Logo" 
     class="auth-logo">

    <span class="badge">Smart Campus Assistant</span>
    <h1>Welcome to SCA Platform</h1>
    <p>
        A modern and smart campus solution that helps students, faculty, administrators,
        and maintenance teams manage their daily tasks efficiently.
    </p>
    <p style="margin-top:20px;">
        Enjoy a clean interface, a professional workflow, and fast access to your campus services.
    </p>
</div>


        <div class="card-right">
            <div class="tabs">
                <button class="tab-btn <?= $mode==='login'?'active':'' ?>" onclick="location.href='index.php?mode=login'">
                    Login
                </button>
                <button class="tab-btn <?= $mode==='register'?'active':'' ?>" onclick="location.href='index.php?mode=register'">
                    Register
                </button>
            </div>

            <?php if($mode === 'register'): ?>
                <?php if($register_message): ?>
                    <div class="success"><?= htmlspecialchars($register_message) ?></div>
                <?php endif; ?>
                <form action="register.php" method="post">
                    <div class="form-group">
                        <label>Full name</label>
                        <input type="text" name="full_name" required>
                    </div>
                    <div class="form-group">
                        <label>University email</label>
                        <input type="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label>Role</label>
                        <select name="role" required>
                            <option value="">Select role</option>
                            <option value="student">Student</option>
                            <option value="faculty">Faculty</option>
                            <option value="maintenance">Maintenance</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Password (min 6 characters)</label>
                        <input type="password" name="password" minlength="6" required>
                    </div>
                    <div class="form-group">
                        <label>Confirm password</label>
                        <input type="password" name="password_confirm" minlength="6" required>
                    </div>
                    <button type="submit" class="btn-primary">Create Account</button>
                </form>
            <?php else: ?>
                <?php if($login_error): ?>
                    <div class="error"><?= htmlspecialchars($login_error) ?></div>
                <?php endif; ?>
                <form action="login.php" method="post">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" required>
                    </div>
                    <button type="submit" class="btn-primary">Login</button>
                </form>
            <?php endif; ?>
        </div>

    </div>
</div>

</body>
</html>
