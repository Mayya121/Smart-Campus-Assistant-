<?php
require_once 'config.php';
require_role(['admin']);

$usersCount = $conn->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'] ?? 0;
$bookingsCount = $conn->query("SELECT COUNT(*) c FROM bookings")->fetch_assoc()['c'] ?? 0;
$openMaint = $conn->query("SELECT COUNT(*) c FROM maintenance_requests WHERE status='open'")->fetch_assoc()['c'] ?? 0;
$feedbackCount = $conn->query("SELECT COUNT(*) c FROM feedback")->fetch_assoc()['c'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard – Smart Campus Assistant</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Admin</div>
            <div class="sidebar-role">System Administrator</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="admin_dashboard.php" class="active">Dashboard</a></li>
            <li><a href="admin_manage_users.php">Manage Users</a></li>
            <li><a href="admin_reports.php">Reports</a></li>
            <li><a href="admin_notifications.php">Notification Settings</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-left">Smart Campus Assistant – Admin Panel</div>
            <div class="topbar-right">
                <a href="logout.php">Logout</a>
            </div>
        </div>

        <div class="content">
            <h1 class="page-title">Dashboard</h1>
            <p class="page-subtitle">Overview of users, bookings, maintenance, and feedback.</p>

            <div class="cards-grid">
                <div class="card-panel">
                    <h3>Total Users</h3>
                    <p>All registered accounts in the system.</p>
                    <div class="big-number"><?= $usersCount ?></div>
                </div>
                <div class="card-panel">
                    <h3>Total Bookings</h3>
                    <p>All classroom and study room reservations.</p>
                    <div class="big-number"><?= $bookingsCount ?></div>
                </div>
                <div class="card-panel">
                    <h3>Open Maintenance</h3>
                    <p>Requests that still require attention.</p>
                    <div class="big-number"><?= $openMaint ?></div>
                </div>
                <div class="card-panel">
                    <h3>Feedback Messages</h3>
                    <p>Student feedback submitted through the portal.</p>
                    <div class="big-number"><?= $feedbackCount ?></div>
                </div>
            </div>

            <div class="form-card">
                <h3>Quick actions</h3>
                <p style="font-size:13px;margin-bottom:10px;">Use the side menu or pick an action below.</p>
                <div style="display:flex;flex-wrap:wrap;gap:10px;">
                    <a class="btn-primary" href="admin_manage_users.php">Manage Users</a>
                    <a class="btn-primary" href="admin_reports.php" style="background:#3AAFA9;">View Reports</a>
                    <a class="btn-primary" href="admin_notifications.php" style="background:#8898a0;">Notification Settings</a>
                </div>
            </div>

        </div>
    </main>

</div>
</body>
</html>
