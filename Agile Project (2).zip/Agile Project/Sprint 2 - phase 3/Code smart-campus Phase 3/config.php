<?php
$host = "localhost";
$dbname = "smart_campus";
$username = "root";
$password = ""; // XAMPP default

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("DB connection failed: " . $conn->connect_error);
}

session_start();

function require_role($roleArray) {
    if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], $roleArray)) {
        header("Location: index.php?mode=login");
        exit;
    }
}

function add_notification($user_id, $type, $message) {
    global $conn;

    $res = $conn->query("SELECT * FROM notification_settings WHERE id = 1");
    if (!$res || $res->num_rows === 0) return;
    $s = $res->fetch_assoc();

    if ($type === 'schedule' && !$s['send_schedule_emails']) return;
    if ($type === 'booking' && !$s['send_booking_emails']) return;
    if ($type === 'maintenance' && !$s['send_maintenance_emails']) return;

    $stmt = $conn->prepare("INSERT INTO notifications (user_id, type, message) VALUES (?,?,?)");
    $stmt->bind_param("iss", $user_id, $type, $message);
    $stmt->execute();
    $stmt->close();
}

function notify_role($role, $type, $message) {
    global $conn;
    $stmt = $conn->prepare("SELECT id FROM users WHERE role = ?");
    $stmt->bind_param("s", $role);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        add_notification($row['id'], $type, $message);
    }
    $stmt->close();
}
