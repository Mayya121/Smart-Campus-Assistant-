<?php
require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = $_POST['role'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['password_confirm'] ?? '';

    if($full_name==='' || $email==='' || $role==='' || $password==='' || $confirm===''){
        $_SESSION['register_message'] = "Please fill in all fields.";
        header("Location: index.php?mode=register"); exit;
    }
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $_SESSION['register_message'] = "Invalid email format.";
        header("Location: index.php?mode=register"); exit;
    }
    if($password !== $confirm){
        $_SESSION['register_message'] = "Passwords do not match.";
        header("Location: index.php?mode=register"); exit;
    }
    if(strlen($password)<6){
        $_SESSION['register_message'] = "Password must be at least 6 characters.";
        header("Location: index.php?mode=register"); exit;
    }

    $stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
    $stmt->bind_param("s",$email);
    $stmt->execute(); $stmt->store_result();
    if($stmt->num_rows>0){
        $_SESSION['register_message'] = "Email already registered.";
        $stmt->close(); header("Location: index.php?mode=register"); exit;
    }
    $stmt->close();

    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO users (full_name,email,password_hash,role) VALUES (?,?,?,?)");
    $stmt->bind_param("ssss",$full_name,$email,$hash,$role);
    if($stmt->execute()){
        $_SESSION['register_message'] = "Account created. You can now log in.";
    } else {
        $_SESSION['register_message'] = "Error creating account.";
    }
    $stmt->close();
    header("Location: index.php?mode=register"); exit;
}
header("Location: index.php?mode=register"); exit;
