<?php
require_once 'config.php';
require_role(['faculty']);

$id = (int)($_GET['id'] ?? 0);
$uid = $_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT b.*, c.name AS room_name 
    FROM bookings b
    JOIN classrooms c ON c.id = b.room_id
    WHERE b.id=? AND b.created_by=? AND b.type='class'
");
$stmt->bind_param("ii",$id,$uid);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$booking){ header("Location: faculty_book_class.php"); exit; }

$msg = '';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $date = $_POST['date'] ?? '';
    $start = $_POST['start_time'] ?? '';
    $end = $_POST['end_time'] ?? '';

    $stmt = $conn->prepare("
        SELECT id FROM bookings
        WHERE room_id=? AND date=? AND status='active' AND id<>?
          AND NOT (end_time <= ? OR start_time >= ?)
    ");
    $stmt->bind_param("isiis",$booking['room_id'],$date,$id,$start,$end);
    $stmt->execute(); $stmt->store_result();
    if($stmt->num_rows>0){
        $msg="Conflict with another booking.";
    } else {
        $stmt->close();
        $stmt = $conn->prepare("
            UPDATE bookings SET date=?, start_time=?, end_time=?, updated_at=NOW()
            WHERE id=? AND created_by=?
        ");
        $stmt->bind_param("sssii",$date,$start,$end,$id,$uid);
        if($stmt->execute()){
            $msg="Booking updated.";
            notify_role('student','schedule',"Classroom booking has been updated on {$date}.");
        } else $msg="Error updating booking.";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Booking – Faculty</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Faculty</div>
            <div class="sidebar-role">Faculty Member</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="faculty_dashboard.php">Dashboard</a></li>
            <li><a href="faculty_book_class.php" class="active">Classroom Booking</a></li>
            <li><a href="faculty_create_maintenance.php">Maintenance Request</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">

        <div class="topbar">
            <div class="topbar-left">Faculty – Edit booking</div>
            <div class="topbar-right"><a href="logout.php">Logout</a></div>
        </div>

        <div class="content">
            <h1 class="page-title">Edit classroom booking</h1>
            <p class="page-subtitle">Update date or time for your reservation.</p>

            <div class="form-card">
                <?php if($msg): ?>
                    <p class="<?= strpos($msg,'updated')!==false?'success':'error' ?>"><?= htmlspecialchars($msg) ?></p>
                <?php endif; ?>

                <form method="post">
                    <p style="font-size:13px;margin-bottom:10px;">Room: <b><?= htmlspecialchars($booking['room_name']) ?></b></p>
                    <div class="form-group">
                        <label>Date</label>
                        <input type="date" name="date" value="<?= htmlspecialchars($booking['date']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Start time</label>
                        <input type="time" name="start_time" value="<?= substr($booking['start_time'],0,5) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>End time</label>
                        <input type="time" name="end_time" value="<?= substr($booking['end_time'],0,5) ?>" required>
                    </div>
                    <button class="btn-primary" type="submit">Save changes</button>
                </form>
            </div>

        </div>
    </main>

</div>
</body>
</html>
