<?php
require_once 'config.php';
require_role(['admin']);

$msg = '';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $s1 = isset($_POST['schedule']) ? 1:0;
    $s2 = isset($_POST['booking']) ? 1:0;
    $s3 = isset($_POST['maintenance']) ? 1:0;
    $stmt = $conn->prepare("
        UPDATE notification_settings 
        SET send_schedule_emails=?, send_booking_emails=?, send_maintenance_emails=? 
        WHERE id=1
    ");
    $stmt->bind_param("iii",$s1,$s2,$s3);
    if($stmt->execute()) $msg="Settings updated.";
    else $msg="Error updating settings.";
    $stmt->close();
}
$settings = $conn->query("SELECT * FROM notification_settings WHERE id=1")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Notification Settings – Admin</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Admin</div>
            <div class="sidebar-role">System Administrator</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li><a href="admin_manage_users.php">Manage Users</a></li>
            <li><a href="admin_reports.php">Reports</a></li>
            <li><a class="active" href="admin_notifications.php">Notification Settings</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-left">Admin – Notification Settings</div>
            <div class="topbar-right"><a href="logout.php">Logout</a></div>
        </div>

        <div class="content">
            <h1 class="page-title">Notification settings</h1>
            <p class="page-subtitle">Enable or disable specific notification types for users.</p>

            <div class="form-card">
                <?php if($msg): ?>
                    <p class="<?= strpos($msg,'updated')!==false ? 'success':'error' ?>"><?= $msg ?></p>
                <?php endif; ?>

                <form method="post">
                    <label><input type="checkbox" name="schedule" <?= $settings['send_schedule_emails']?'checked':'' ?>> Schedule notifications</label><br><br>
                    <label><input type="checkbox" name="booking" <?= $settings['send_booking_emails']?'checked':'' ?>> Booking notifications</label><br><br>
                    <label><input type="checkbox" name="maintenance" <?= $settings['send_maintenance_emails']?'checked':'' ?>> Maintenance notifications</label><br><br>
                    <button class="btn-primary" type="submit">Save settings</button>
                </form>
            </div>

        </div>
    </main>

</div>
</body>
</html>
