<?php
require_once 'config.php';
require_role(['student']);

$uid = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT COUNT(*) c FROM bookings WHERE created_by=? AND type='study'");
$stmt->bind_param("i",$uid);
$stmt->execute();
$studyCount = $stmt->get_result()->fetch_assoc()['c'] ?? 0;
$stmt->close();

$stmt = $conn->prepare("SELECT COUNT(*) c FROM notifications WHERE user_id=?");
$stmt->bind_param("i",$uid);
$stmt->execute();
$notifCount = $stmt->get_result()->fetch_assoc()['c'] ?? 0;
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard – Smart Campus Assistant</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Student</div>
            <div class="sidebar-role">Student Portal</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="student_dashboard.php" class="active">Dashboard</a></li>
            <li><a href="student_schedule.php">Daily Schedule</a></li>
            <li><a href="student_study_room.php">Study Room Booking</a></li>
            <li><a href="student_feedback.php">Send Feedback</a></li>
            <li><a href="student_notifications.php">Notifications</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-left">Smart Campus Assistant – Student Panel</div>
            <div class="topbar-right">
                <a href="logout.php">Logout</a>
            </div>
        </div>

        <div class="content">
            <h1 class="page-title">Dashboard</h1>
            <p class="page-subtitle">Access your schedule, study rooms, feedback, and notifications.</p>

            <div class="cards-grid">
                <div class="card-panel">
                    <h3>Study room bookings</h3>
                    <p>Study rooms you reserved.</p>
                    <div class="big-number"><?= $studyCount ?></div>
                    <a href="student_study_room.php" class="btn-primary" style="margin-top:8px;">Manage bookings</a>
                </div>
                <div class="card-panel">
                    <h3>Notifications</h3>
                    <p>Updates related to your account.</p>
                    <div class="big-number"><?= $notifCount ?></div>
                    <a href="student_notifications.php" class="btn-primary" style="margin-top:8px;background:#3AAFA9;">View notifications</a>
                </div>
                <div class="card-panel">
                    <h3>Today schedule</h3>
                    <p>Check your classes schedule for today.</p>
                    <a href="student_schedule.php" class="btn-primary" style="margin-top:8px;background:#8898a0;">View schedule</a>
                </div>
            </div>

        </div>
    </main>

</div>
</body>
</html>
