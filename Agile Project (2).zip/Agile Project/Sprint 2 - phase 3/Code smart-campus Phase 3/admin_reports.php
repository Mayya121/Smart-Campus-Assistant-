<?php
require_once 'config.php';
require_role(['admin']);

$usersCount = $conn->query("SELECT role, COUNT(*) c FROM users GROUP BY role");
$bookingsCount = $conn->query("SELECT type,status, COUNT(*) c FROM bookings GROUP BY type,status");
$feedbackCount = $conn->query("SELECT COUNT(*) c FROM feedback")->fetch_assoc()['c'] ?? 0;
$maintCount = $conn->query("SELECT status, COUNT(*) c FROM maintenance_requests GROUP BY status");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reports – Admin</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Admin</div>
            <div class="sidebar-role">System Administrator</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li><a href="admin_manage_users.php">Manage Users</a></li>
            <li><a class="active" href="admin_reports.php">Reports</a></li>
            <li><a href="admin_notifications.php">Notification Settings</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-left">Admin – Reports</div>
            <div class="topbar-right"><a href="logout.php">Logout</a></div>
        </div>

        <div class="content">
            <h1 class="page-title">System reports</h1>
            <p class="page-subtitle">Overview of system data (read-only).</p>

            <div class="table-wrapper">
                <h3 style="margin-bottom:10px;">Users by role</h3>
                <table>
                    <thead>
                        <tr><th>Role</th><th>Count</th></tr>
                    </thead>
                    <tbody>
                        <?php while($u=$usersCount->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($u['role']) ?></td>
                                <td><?= $u['c'] ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <div class="table-wrapper">
                <h3 style="margin-bottom:10px;">Bookings by type & status</h3>
                <table>
                    <thead>
                        <tr><th>Type</th><th>Status</th><th>Count</th></tr>
                    </thead>
                    <tbody>
                        <?php while($b=$bookingsCount->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($b['type']) ?></td>
                                <td><?= htmlspecialchars($b['status']) ?></td>
                                <td><?= $b['c'] ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <div class="table-wrapper">
                <h3 style="margin-bottom:10px;">Maintenance requests</h3>
                <table>
                    <thead>
                        <tr><th>Status</th><th>Count</th></tr>
                    </thead>
                    <tbody>
                        <?php while($m=$maintCount->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($m['status']) ?></td>
                                <td><?= $m['c'] ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <div class="form-card">
                <h3>Total feedback messages: <?= $feedbackCount ?></h3>
            </div>

        </div>
    </main>

</div>
</body>
</html>
