<?php
require_once 'config.php';

if($_SERVER['REQUEST_METHOD']==='POST'){
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if($email==='' || $password===''){
        $_SESSION['login_error']="Please enter email and password.";
        header("Location: index.php?mode=login"); exit;
    }

    $stmt = $conn->prepare("SELECT id,full_name,password_hash,role FROM users WHERE email=?");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();
    $stmt->close();

    if(!$user || !password_verify($password, $user['password_hash'])){
        $_SESSION['login_error']="Incorrect email or password.";
        header("Location: index.php?mode=login"); exit;
    }

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['full_name'];
    $_SESSION['user_role'] = $user['role'];

    if($user['role']==='admin') header("Location: admin_dashboard.php");
    elseif($user['role']==='faculty') header("Location: faculty_dashboard.php");
    elseif($user['role']==='maintenance') header("Location: maintenance_dashboard.php");
    else header("Location: student_dashboard.php");
    exit;
}
header("Location: index.php?mode=login"); exit;
