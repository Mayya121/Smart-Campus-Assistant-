<?php
require_once 'config.php';
require_role(['student']);

$msg = '';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $text = trim($_POST['message'] ?? '');
    if($text!==''){
        $sid = $_SESSION['user_id'];
        $stmt = $conn->prepare("INSERT INTO feedback (student_id,message) VALUES (?,?)");
        $stmt->bind_param("is",$sid,$text);
        if($stmt->execute()) $msg="Feedback submitted. Thank you!";
        else $msg="Error sending feedback.";
        $stmt->close();
    } else $msg="Please write your feedback.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send Feedback – Student</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Student</div>
            <div class="sidebar-role">Student Portal</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="student_dashboard.php">Dashboard</a></li>
            <li><a href="student_schedule.php">Daily Schedule</a></li>
            <li><a href="student_study_room.php">Study Room Booking</a></li>
            <li><a class="active" href="student_feedback.php">Send Feedback</a></li>
            <li><a href="student_notifications.php">Notifications</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-left">Student – Feedback</div>
            <div class="topbar-right"><a href="logout.php">Logout</a></div>
        </div>

        <div class="content">
            <h1 class="page-title">Send feedback</h1>
            <p class="page-subtitle">Help us improve the campus experience.</p>

            <div class="form-card">
                <?php if($msg): ?>
                    <p class="<?= strpos($msg,'submitted')!==false?'success':'error' ?>"><?= htmlspecialchars($msg) ?></p>
                <?php endif; ?>

                <form method="post">
                    <div class="form-group">
                        <label>Your feedback</label>
                        <textarea name="message" rows="5" required></textarea>
                    </div>
                    <button class="btn-primary" type="submit">Submit</button>
                </form>
            </div>

        </div>
    </main>

</div>
</body>
</html>
