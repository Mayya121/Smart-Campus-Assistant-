<?php
require_once 'config.php';
require_role(['maintenance']);

$msg = '';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $id = (int)($_POST['request_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    if($id && in_array($status,['open','in_progress','done'])){
        $stmt = $conn->prepare("SELECT created_by,title FROM maintenance_requests WHERE id=?");
        $stmt->bind_param("i",$id);
        $stmt->execute();
        $res = $stmt->get_result();
        $req = $res->fetch_assoc();
        $stmt->close();

        if($req){
            $uid = $_SESSION['user_id'];
            $stmt = $conn->prepare("
                UPDATE maintenance_requests 
                SET status=?, assigned_to=?, updated_at=NOW()
                WHERE id=?
            ");
            $stmt->bind_param("sii",$status,$uid,$id);
            if($stmt->execute()){
                $msg="Request updated.";
                add_notification($req['created_by'],'maintenance',"Your maintenance request '{$req['title']}' is now {$status}.");
            }
        }
    }
}

$res = $conn->query("
    SELECT mr.id, u.full_name AS created_by, mr.title, mr.description, mr.status, mr.created_at
    FROM maintenance_requests mr
    JOIN users u ON u.id=mr.created_by
    ORDER BY mr.created_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Maintenance Requests – Maintenance Staff</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-layout">

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">SCA Maintenance</div>
            <div class="sidebar-role">Maintenance Staff</div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="maintenance_dashboard.php">Dashboard</a></li>
            <li><a class="active" href="maintenance_requests.php">Maintenance Requests</a></li>
        </ul>
        <div class="sidebar-footer">
            Logged in as: <?= htmlspecialchars($_SESSION['user_name']) ?>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-left">Maintenance – Requests</div>
            <div class="topbar-right"><a href="logout.php">Logout</a></div>
        </div>

        <div class="content">
            <h1 class="page-title">Maintenance requests</h1>
            <p class="page-subtitle">View and update the status of all requests.</p>

            <?php if($msg): ?>
                <p class="<?= strpos($msg,'updated')!==false?'success':'error' ?>"><?= $msg ?></p>
            <?php endif; ?>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>From</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while($r=$res->fetch_assoc()): ?>
                        <tr>
                            <td><?= $r['id'] ?></td>
                            <td><?= htmlspecialchars($r['created_by']) ?></td>
                            <td><?= htmlspecialchars($r['title']) ?></td>
                            <td><?= htmlspecialchars($r['description']) ?></td>
                            <td><?= htmlspecialchars($r['status']) ?></td>
                            <td>
                                <form method="post" style="display:flex;gap:6px;">
                                    <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                                    <select name="status" style="padding:6px;">
                                        <option value="open" <?= $r['status']==='open'?'selected':'' ?>>open</option>
                                        <option value="in_progress" <?= $r['status']==='in_progress'?'selected':'' ?>>in_progress</option>
                                        <option value="done" <?= $r['status']==='done'?'selected':'' ?>>done</option>
                                    </select>
                                    <button class="table-action-btn" type="submit">Update</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </main>

</div>
</body>
</html>
